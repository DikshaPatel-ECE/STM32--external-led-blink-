const int ledPin = PB0;       // External LED on PB0
const int buttonPin = PA0;    // Button on PA0

void setup() {
  pinMode(ledPin, OUTPUT);          // LED pin as output
  pinMode(buttonPin, INPUT_PULLUP); // Button with internal pull-up
}

void loop() {
  int buttonState = digitalRead(buttonPin);

  if (buttonState == LOW) {
    digitalWrite(ledPin, HIGH);   // External LED ON
  } else {
    digitalWrite(ledPin, LOW);    // External LED OFF
  }
}
